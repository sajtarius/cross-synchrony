#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 19:13:18 2024

@author: hengjie
"""

# @title UPDATED [cross synchrony divergence] calculation for a system --> cross_synch_sys()
import numpy as np

from synchro_code import hellinger_distance
from tqdm import tqdm
from scipy.stats import wasserstein_distance as wass_dist
from scipy.spatial.distance import jensenshannon
from joblib import Parallel, delayed

def cross_synch_sys(data, exp_range=2.0, bins=500, check_mean=1.0, check_std=0.1, check_pdf_info=True, method='hellinger'):
    assert isinstance(data, np.ndarray), 'data: given data should be in numpy.array format.'
    assert len(data.shape) == 3, 'data: given data should have 3 dimensions of NxNxT.'
    assert data.shape[0] == data.shape[1], 'data: given data should be a square matrix in the first 2 dimensions; NxNxT.'
    assert data.shape[2] >= 10, 'data: given the sequence of the data should have at least 10.'
    assert isinstance(exp_range, (int, float)), 'exp_range: expected distribution range should be in integer or float.'
    assert exp_range >= 1.0, 'exp_range: expected distribution range should be at least 1; default is 2.0.'
    assert (bins=='rice') or (bins=='sturges') or (type(bins)==int), 'bins: estimated bin size for the distribution estimation should be integer or string. bin size estimation options are [rice], [sturges]; default is 500.'
    assert isinstance(check_mean, (int, float)), 'check_mean: mean of the [reference normal distribution] should be in integer or float.'
    assert np.abs(check_mean) <= 1.0, 'check_mean: mean of the [reference normal distribution] should be in the range of [-1, 1]; default is 1.'
    assert isinstance(check_std, (int, float)), 'check_std: std of the [reference normal distribution] should be in integer or float.'
    assert check_std > 0, 'check_std: std of the [reference normal distribution] should be more than 0; default is 0.01.'
    assert isinstance(check_pdf_info, (bool)), 'check_pdf_info: info of the distribution for sanity check; default is True.'
    assert isinstance(method, (str)), 'method: method used to compare the distribution; default is [hellinger]. Options: [hellinger], [jensen], [wass]'
    assert (method=='hellinger') or (method=='jensen') or (method=='wass'), 'method: method options are [hellinger], [jensen], [wass]; default is [hellinger].'

    temp_data_seq = data

    #extracting the data of the [upper triangle of the sequence] from [phase lock matrix sequence]
    ##for-loop method -- **it runs faster; why?
    temp_upind = np.triu_indices(temp_data_seq.shape[0], k=1) #indices of the upper triangle
    up_data = []
    for t in tqdm(range(temp_data_seq.shape[2]), position=0):
        temp_up_data = temp_data_seq[:,:,t][temp_upind]
        up_data.append(temp_up_data)
    up_data = np.array(up_data).T #return [upper triangle data x T]
    up_data = up_data.flatten()

    ##parallel method -- **it runs slower than [for-loop method]; why? 
    '''temp_upind = np.triu_indices(temp_data_seq.shape[0], k=1)
    def triup_seq(data, i, index):
        assert data.shape[0] == data.shape[1], 'data: given data should be a square matrix sequence; NxNxT.'
        assert isinstance(i, (int)), 'i: time index of the data; it should be integer.'
        assert isinstance(index, (tuple)), 'index: indices for the upper triangle; it should be tuple.'
        assert isinstance(index[0], (np.ndarray)), 'index: indices for the first array should be numpy.array.'
        assert isinstance(index[1], (np.ndarray)), 'index: indices for the second array should be numpy.array.'
        assert index[0].shape[0] == index[1].shape[0], 'index: the indices for the two array should be having the same length.'

        temp_up_data = data[:,:,i][index]

        return temp_up_data

    up_data = Parallel(n_jobs=-1)(delayed(triup_seq)(temp_data_seq, t, temp_upind) for t in tqdm(range(temp_data_seq.shape[2]), position=0))
    up_data = up_data.flatten()'''

    #PDF & PMF of the given data
    dist_range = (-1*exp_range, exp_range) #range of the distribution
    if type(bins)==int:
        temp_bins = bins #bin size for the histogram: from the input
    elif bins=='rice':
        temp_bins = int(np.ceil(2 * (up_data.shape[-1])**(1/3))) #bin size for the histogram: rice rule
    elif bins=='sturges':
        temp_bins = int(np.ceil(np.log2(up_data.shape[-1])) + 1) #bin size for the histogram: sturges's formula

    temp_pdf, temp_edges = np.histogram(up_data, bins=temp_bins, range=(np.min(dist_range), np.max(dist_range)), density=True)
    temp_pmf = temp_pdf * np.diff(temp_edges)[0]
    if check_pdf_info:
      print(f'check PMF of data: \t {np.sum(temp_pmf)}')
      temp_mean = np.sum(temp_pmf*((temp_edges[:-1]+temp_edges[1:])/2))
      temp_std = np.sum(((((temp_edges[:-1]+temp_edges[1:])/2) - temp_mean)**2) * (temp_pmf))**(1/2)
      print(f'mean of data: \t {temp_mean}')
      print(f'std of data: \t {temp_std}')

    #PDF & PMF of the normal distribution
    temp_mean, temp_std = check_mean, check_std
    temp_normal_data = np.random.normal(temp_mean, temp_std, size=100_000)
    temp_normal_pdf, temp_normal_edges = np.histogram(temp_normal_data, bins=temp_bins, range=(np.min(dist_range), np.max(dist_range)), density=True)
    temp_normal_pmf = temp_normal_pdf * np.diff(temp_normal_edges)[0]
    if check_pdf_info:
      print(f'check PMF of normal: \t {np.sum(temp_normal_pmf)}')
      temp_check_normal_mean = np.sum(temp_normal_pmf*((temp_normal_edges[:-1]+temp_normal_edges[1:])/2))
      temp_check_normal_std = np.sum(((((temp_normal_edges[:-1]+temp_normal_edges[1:])/2) - temp_check_normal_mean)**2) * (temp_normal_pmf))**(1/2)
      print(f'check normal PMF mean: \t {temp_check_normal_mean}')
      print(f'check normal PMF std: \t {temp_check_normal_std}')
      print(f'bin size of PMF: {temp_bins}')

    #evaluate the difference between the PMF
    if method == 'hellinger':
        temp_data_js = hellinger_distance(temp_pmf, temp_normal_pmf) #hellinger distance

    if method == 'jensen':
        temp_data_js = jensenshannon(temp_pmf, temp_normal_pmf)  #jensen divergence

    if method == 'wass':
        temp_data_js = wass_dist(temp_pmf, temp_normal_pmf) #wasserstein distance

    return temp_data_js