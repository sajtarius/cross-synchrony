#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 20:31:01 2024

@author: hengjie
"""

# @title [global functional connectivity] calculation --> global_func_connect()
import numpy as np

from scipy.fft import rfft, rfftfreq
from joblib import Parallel, delayed

def process_channel(channel_data, int_freq, timerange):
    temp_fouramp = rfft(channel_data)
    temp_fourfreq = rfftfreq(channel_data.shape[0], d=np.diff(timerange)[0])
    temp_freqloc = np.where(temp_fourfreq <= int_freq)[0][-1]
    temp_compnum = temp_fouramp[temp_freqloc]
    return temp_compnum

def global_func_connect(data, int_freq, time):
    assert isinstance(data, (np.ndarray)), 'data: data should be in np.array form for calculation'
    assert len(data.shape) == 2, 'data: data should be TWO dimensional array in NxT'
    assert data.shape[0] >= 2, 'data: data should have at least 2 channels.'
    assert data.shape[1] >= 10, 'data: data should have at least 10 time data points.'
    assert isinstance(int_freq, (int, float)), 'int_freq: interested frequency should be in integer or float number.'
    assert isinstance(time, (np.ndarray)), 'time: time data should be in np.array form for calculation.'
    assert data.shape[1] == time.shape[0], 'BOTH [data] and [time] need to be in same length.'
    
    temp_data = data
    temp_time_data = time # time data
    
    results = Parallel(n_jobs=-1)(
        delayed(process_channel)(temp_data[i], int_freq, temp_time_data) for i in range(temp_data.shape[0])
    )
    
    temp_complex = np.array(results)
    
    return temp_complex
