#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 20:45:42 2024

@author: hengjie
"""

# @title [global field synchonization] calculation --> global_field_sync()
#this function requires the [global functional connectivity] function (global_func_connect()).
import numpy as np

from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

def global_field_sync(data):
    assert isinstance(data, (np.ndarray)), 'data: given data needs to be np.array format for the calculation.'
    assert len(data.shape) == 1, 'data: data should be a ONE dimension array.'
    
    temp_datax = [np.real(value) for value in data] #collection of the real part of the complex numbers
    temp_datay = [np.imag(value) for value in data] #collection of the imaginary part of the complex numbers
    clf = PCA(n_components=2)
    scalar = StandardScaler()
    
    temp_pca_input = np.stack((temp_datax, temp_datay), axis=1) #stack the array in the form of (n_samples, n_features)
    #temp_pca_input = scalar.fit_transform(temp_pca_input) #scaling the data 
    
    temp_eigval = clf.fit(temp_pca_input).explained_variance_  #eigenvalues of the PCA
    
    temp_gfs = (np.abs(temp_eigval[0] - temp_eigval[1]))/(temp_eigval[0] + temp_eigval[1])
    
    return temp_gfs
