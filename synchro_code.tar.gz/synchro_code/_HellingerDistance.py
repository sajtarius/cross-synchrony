#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 19:12:19 2024

@author: hengjie
"""

# @title [hellinger distance] calculation --> hellinger_distance()
import numpy as np

def hellinger_distance(p, q):
    # Check if the lengths of the two distributions are equal
    if len(p) != len(q):
        raise ValueError("Distributions must have the same length")

    # Convert distributions to numpy arrays
    p = np.array(p)
    q = np.array(q)

    # Compute the Hellinger distance
    distance = np.sqrt(0.5 * np.sum((np.sqrt(p) - np.sqrt(q))**2))

    return distance