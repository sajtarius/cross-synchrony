#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 19:16:17 2024

@author: hengjie
"""

# @title [phase lock matrix] sequence --> phase_lock_seq()
import numpy as np

from tqdm import tqdm
from scipy.signal import hilbert

def phase_lock_seq(data):
    assert isinstance(data, np.ndarray), 'data: given data should be in numpy.array format.'
    assert len(data.shape) == 2, 'data: given data should have 2 dimensions of NxT.'
    assert data.shape[0] >= 2, 'data: given data should have at least 2 series.'
    assert data.shape[1] >= 10, 'data: given data should have at least contain 10 data points (time points).'

    temp_data = data
    temp_hilbert = hilbert(temp_data)
    temp_hilbert_radian = np.unwrap(np.angle(temp_hilbert, deg=False)) #getting the angle in radian

    temp_hilbert_angle = temp_hilbert_radian

    #pre-define phase lock matrix sequence with [NxNxT] dimension
    temp_phase_lock = np.zeros((temp_hilbert_angle.shape[0], temp_hilbert_angle.shape[0], temp_hilbert_angle.shape[1]))

    for i in tqdm(range(temp_hilbert_angle.shape[0]), position=0):
        for j in range(temp_hilbert_angle.shape[0]):
            temp_angle_diff = temp_hilbert_angle[i] - temp_hilbert_angle[j]
            temp_phase_lock[i, j, :] = np.cos(temp_angle_diff)

    #return the [phase lock matrix] sequences.
    return temp_phase_lock